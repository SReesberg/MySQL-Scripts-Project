/*
FileName: Stored_Procedure_Update.sql
Programmer Name: Stefan Reesberg
Description: This file creates an update procedure that will update an existing pet type record.
*/

USE TygervalleyPetShelter
GO
--This stored procedure will update the number of pets in stock in a pet type record.
CREATE PROCEDURE sp_UpdateStock
	--User supplied values	
	@petType VARCHAR(30),
	@numberOfPets INT,
	@addSubtract SMALLINT
AS
BEGIN
	IF (@numberOfPets < 0) -- Checks to ensure negative values are not entered
	BEGIN
		RAISERROR('Negative numbers are not accepted.',16,1)
		RETURN
	END

	UPDATE Pet --Updates the quantity of pets inside the record
	SET numberOfPets = CASE @addSubtract WHEN 1 THEN @numberOfPets + numberOfPets ELSE numberOfPets - @numberOfPets END
	WHERE petType = @petType

END
GO

--The commented test can be run by highlighting the lines and executing.
EXEC sp_UpdateStock 'Frog',15, 1 --ADDS the specified amount of pets to the record

--EXEC sp_UpdateStock 'Frog',15, 0 --SUBTRACTS the specified amount of pets from the record

--EXEC sp_UpdateStock 'Frog',-1, 1 --Incorrect. Negative quantity
GO

--Test to see if update was successful
SELECT *
FROM Pet