/*
FileName: Store_Procedure_Report.sql
Programmer Name: Stefan Reesberg
Description: This file creates a Report using procedures that will display a manufacturer's details and all expired products in use.
*/

USE TygervalleyPetShelter
GO

--Displaying a supplier's details
CREATE PROCEDURE sp_Report
    --User supplied values
	@reqcompanyName VARCHAR (30)
AS
BEGIN
	--Validating user input
	IF NOT EXISTS(SELECT 1
			      FROM Supplier
				  WHERE companyName = @reqcompanyName)
	BEGIN
		RAISERROR('This company does not exist.',16,1,@reqcompanyName)
		RETURN
	END

	--Declaring all variables and retrieving all info to display in the report
	DECLARE @recordCount INT;
	SET @recordCount = (SELECT COUNT(*) FROM vw_ExpiredFoodDetails WHERE [Company Name] = @reqcompanyName)
	
	DECLARE @companyName VARCHAR(30);
	SET @companyName = (SELECT TOP 1 [Company Name] FROM vw_ExpiredFoodDetails WHERE [Company Name] = @reqcompanyName)

	DECLARE @contactNum VARCHAR(30);
	SET @contactNum = (SELECT TOP 1 [Contact Number] FROM vw_ExpiredFoodDetails WHERE [Company Name] = @reqcompanyName)

	DECLARE @companyEmail VARCHAR(30);
	SET @companyEmail = (SELECT TOP 1 [Company Email] FROM vw_ExpiredFoodDetails WHERE [Company Name] = @reqcompanyName)

	DECLARE @companyID INT;
	SET @companyID = (SELECT TOP 1 [Company ID] FROM vw_ExpiredFoodDetails WHERE [Company Name] = @reqcompanyName)

	--Printing the heading of the report
	PRINT('EXPIRED PRODUCT REPORT:')
	PRINT('______________________________________________')
	PRINT('') --Creating a space underneath the heading

	PRINT('Generated:')
	PRINT(GETDATE()) --Display the current date  and time
	PRINT('')

	PRINT('Company ID:        ' + CAST (@companyID AS VARCHAR(99))) --Display the companyID of  the manufacturer in the report
	PRINT('Company Name:      ' + (@companyName)) --Display the name of the manufacturer in the report
	PRINT('Company Number:    ' + (@contactNum)) -- Display the mannufacturer's contact number in the report
	PRINT('Email:             ' + (@companyEmail)) --Display the email of the manufacturer in the report
	
	PRINT('______________________________________________')
	PRINT('Food ID    Food Type')
	PRINT('______________________________________________')
	
	DECLARE @foodID VARCHAR(4) 
	DECLARE @foodType VARCHAR(30)

	--Declaring the cursor
	DECLARE Food_Cursor CURSOR FOR

	SELECT [Food ID], [Food Name]
	FROM vw_ExpiredFoodDetails
	WHERE [Company Name] = @reqcompanyName
	
	OPEN Food_Cursor;  --Using the cursor

	FETCH NEXT FROM Food_Cursor 
	INTO @foodID, @foodType;

	--While loop that runs through records
	WHILE @@FETCH_STATUS = 0
	BEGIN
	   PRINT @foodID + '       '+   @foodType 
	   FETCH NEXT FROM Food_Cursor  --Retrieves the next record
	   INTO @foodID, @foodType;
	END;

	--Closes and deallocates the cursor
	CLOSE Food_Cursor;
	DEALLOCATE Food_Cursor;

	PRINT('_____________________')
	PRINT('Total Records: ' + CAST (@recordCount AS VARCHAR (3)))  --Print out accumulated record for the specified manufacturing company
	PRINT('_____________________')

END
GO

--Testing the procedure
EXEC sp_Report 'Pets R Us'
GO
--Example of a failure , highlight and execute to test validation
--EXEC sp_Report 'We dislike Pets'
--GO