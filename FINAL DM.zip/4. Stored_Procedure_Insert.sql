/*
FileName: Stored_Procedure_Insert.sql
Programmer Name: Stefan Reesberg
Description: This file creates an insert procedure that will add a new pet type record.
*/

USE TygervalleyPetShelter
GO
--This stored procedure will add another pet to our Pets table
CREATE PROCEDURE sp_NewPetType
     --User supplied values
	@petID VARCHAR(4),
	@petType VARCHAR(30),
	@numberOfPets INT,
	@animalCategory VARCHAR(10)
AS
BEGIN
	--Checks to ensure the maximum intake of 25 pets per instance is not exceeded.
	IF(@numberOfPets > 25)
	BEGIN
		RAISERROR('TPS can only handle an intake of 25 or less pets of the same type at one time.',16,1)
		RETURN
	END 

	INSERT INTO Pet(petID,petType,numberOfPets,animalID) --Inserts the new pet record
	VALUES(@petID,@petType,@numberOfPets,(SELECT animalID FROM Animal WHERE animalCategory = @animalCategory)) --Using the variables

END
GO

EXEC sp_NewPetType '08','Rattlesnake',6,'Reptile'
GO

--A example of a failed test that can be run by highlighting and executing the code below.
--EXEC sp_NewPetType '15','Iguana',26,'Reptile'  Incorrect. Too many pets.
--GO

--Test if insert was executed successfully
SELECT * 
FROM Pet