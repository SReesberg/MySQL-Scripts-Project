/* 
FileName: Sample_Data_Insert.sql
Programmer: Stefan Reesberg
Description: This file will insert sample data into the database.
*/

USE TygervalleyPetShelter
GO


INSERT INTO Supplier(companyName,contactNum,companyEmail) --Inserts sample data into the Supplier table.
VALUES('Pets R Us','0795266072','www.petsrus@gmail.com'),
	  ('The Pet Company','0824533559','www.TPC@gmail.com'),
	  ('Real Meats','0794566059','www.realmeats@gmail.com'),
	  ('Animal Care Incorporated','0219815612', 'www.animalcareinc@gmail,com')
GO

--To ensure data integrity of all IDs, validation was used in the form of SELECT FROM WHERE to avoid imperfect entries
INSERT INTO Food(foodID,foodType, expiryDate,companyID) --Inserts sample data into the Food table.
VALUES('S001','Bird Seed','1 January 2022', (SELECT CompanyID FROM Supplier WHERE companyName ='Pets R Us')),        
	  ('P001','Dog Pellets','12 May 2022',(SELECT CompanyID FROM Supplier WHERE companyName ='The Pet Company')),
	  ('P011','Cat Pellets','14 May 2022',(SELECT CompanyID FROM Supplier WHERE companyName ='The Pet Company')),
	  ('F001','Raw Dog Feed','1 March 2022',(SELECT CompanyID FROM Supplier WHERE companyName ='Real Meats')),
	  ('T001','Dog Biltong Chews','2 July 2022',(SELECT CompanyID FROM Supplier WHERE companyName ='Real Meats')),
	  ('C011','Canned Cat Food','21 April 2022',(SELECT CompanyID FROM Supplier WHERE companyName ='Pets R Us')),
	  ('C001','Canned Dog Food','3 March 2022',(SELECT CompanyID FROM Supplier WHERE companyName ='Pets R Us'))
GO

INSERT INTO Animal(animalID,animalCategory) --Inserts sample data into the Animal table.
VALUES('011','Mammal'),
	  ('012','Bird'),
	  ('013','Reptile'),
	  ('014','Amphibian')
GO

INSERT INTO Pet(petID,petType,numberOfPets,animalID) --Inserts sample data into the Pet table.
VALUES('01','Parrot',10,(SELECT animalID FROM Animal WHERE animalCategory = 'Bird')),
	  ('02','Cat',15,(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal')),
	  ('03','Dog',12,(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal')),
	  ('04','Bearded Dragon',3,(SELECT animalID FROM Animal WHERE animalCategory = 'Reptile')),
	  ('05','Frog',5,(SELECT animalID FROM Animal WHERE animalCategory = 'Amphibian')),
	  ('06','African Grey',4,(SELECT animalID FROM Animal WHERE animalCategory = 'Bird')),
	  ('07','Monkey',2,(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal'))
GO

INSERT INTO FoodAnimal (foodID,animalID,amountOfFood) --Inserts sample data into the FoodAnimal table.
VALUES((SELECT foodID FROM Food WHERE foodType = 'Bird Seed'),(SELECT animalID FROM Animal WHERE animalCategory = 'Bird'),500), --Per unit weight in grams to avoid clutter
      ((SELECT foodID FROM Food WHERE foodType = 'Dog Pellets'),(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal'),1000),
	  ((SELECT foodID FROM Food WHERE foodType = 'Cat Pellets'),(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal'),1500),
	  ((SELECT foodID FROM Food WHERE foodType = 'Raw Dog Feed'),(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal'),750),
	  ((SELECT foodID FROM Food WHERE foodType = 'Dog Biltong Chews'),(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal'),250),
	  ((SELECT foodID FROM Food WHERE foodType = 'Canned Cat Food'),(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal'),350),
	  ((SELECT foodID FROM Food WHERE foodType = 'Canned Dog Food'),(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal'),350)
GO