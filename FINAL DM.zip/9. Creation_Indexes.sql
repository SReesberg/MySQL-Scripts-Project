/*
FileName: Creation_Indexes.sql
Programmer Name: Stefan Reesberg
Description: This file creates indexes for every table present in the Tygervalley Pet Shelter spreadsheet.
*/

USE TygervalleyPetShelter
GO

--Creating a non-clustered index on the animalID column.
CREATE INDEX ix_animalID
ON Animal
( 
	animalID
)
GO

--Creating a non-clustered index on the foodID column.
CREATE INDEX ix_foodID
ON Food
( 
	foodID
)
GO

--Creating a non-clustered index on the foodID column in FoodAnimal.
CREATE INDEX ix_foodID
ON FoodAnimal
( 
	foodID
)
GO

--Creating a non-clustered index on the animalID column.
CREATE INDEX ix_animalID
ON FoodAnimal
( 
	animalID
)
GO

--Creating a non-clustered index on the petID column.
CREATE INDEX ix_petID
ON Pet
( 
	petID
)
GO

--Creating a non-clustered index on the companyID column.
CREATE INDEX ix_companyID
ON Supplier
( 
	companyID
)
GO

