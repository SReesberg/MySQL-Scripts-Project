/*
FileName: Stored_Procedure_Delete.sql
Programmer Name: Stefan Reesberg
Description: This file creates a delete procedure that will delete an expired food type.
*/

USE TygervalleyPetShelter
GO

--Deleting a food type
CREATE PROCEDURE sp_DeleteFoodType 
	--User supplied values
	@chosenFoodID VARCHAR (4)
AS	
BEGIN
	--Checking to see if the foodID exists
	IF NOT EXISTS(SELECT 1 
			  FROM Food
			  WHERE foodID = @chosenFoodID)
	BEGIN
		RAISERROR('This foodID does not exist.',16,1,@chosenFoodID)
		RETURN
	END
	
	--First we delete from the FoodAnimal intersection table
	BEGIN
		DELETE 
		FROM FoodAnimal 
		WHERE foodID IN (SELECT foodID FROM Food WHERE expiryDate <= GETDATE()) AND foodID = @chosenFoodID --check if the food is expired and corresponds to the input ID
	END
	
	--Then we delete from the Food table
	BEGIN
		DELETE 
		FROM Food 
		WHERE foodID IN (SELECT foodID FROM Food WHERE expiryDate <= GETDATE()) AND foodID = @chosenFoodID --check if the food is expired and corresponds to the input ID
	END

END
GO
--Testing the delete procedure
EXEC sp_DeleteFoodType 'S001'
GO

--Test an incorrect foodID
--EXEC sp_DeleteFoodType 'Z001'
--GO

--Test to see if the deletion was successful
SELECT*
FROM Food