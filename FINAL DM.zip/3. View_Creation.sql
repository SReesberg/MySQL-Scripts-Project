/*
FileName: View_Creation.sql
Programmer Name: Stefan Reesberg
Description This file will be used to create a view for Tygervalley Pet Shelter
*/

--NOTE: Please use the commented test views in order to display the created views by highlighting the command and using execute.
USE TygervalleyPetShelter
GO

CREATE VIEW vw_ManufacturerDetails --Creates a view selecting the company details, food type, foodID and amount per category
AS
SELECT Supplier.*,Food.foodType, Food.foodID, FoodAnimal.amountOfFood 
FROM Supplier 
	INNER JOIN Food ON Supplier.companyID = Food.companyID --joining related keys between tables
	INNER JOIN FoodAnimal ON Food.foodID = FoodAnimal.foodID
--SELECT * FROM vw_ManufacturerDetails (Test View)
GO

CREATE VIEW vw_PetsPerType --Creates a view selecting each animal type, total animals in stock, animal category ID and the category name
AS
SELECT Animal.animalID AS 'Animal Category ID', Animal.animalCategory AS 'Category Name', Pet.petType AS 'Animal Type', SUM(numberOfPets) AS 'Total Animals In Stock' --Use of AS to create neat headings.
FROM Pet
	INNER JOIN Animal ON Pet.animalID = Animal.animalID --joining related keys between tables

GROUP BY Pet.petType, Animal.animalCategory, Animal.animalID --Groups results by ID, Category Name, Animal Type, Total Animals
-- SELECT * FROM vw_PetsPerType (Test View)
GO 

CREATE VIEW vw_ExpiredFoodDetails --Creates a view selecting expired products together with their company details.
AS
SELECT Supplier.companyName AS 'Company Name', --AS for cleaner headings
	   Supplier.contactNum AS 'Contact Number', 
	   Food.foodID AS 'Food ID',
	   Food.foodType AS 'Food Name', 
	   Food.expiryDate AS 'Expiry Date', 
	   FoodAnimal.amountOfFood AS 'Amount Per Category', 
	   Animal.animalCategory AS 'Category Name',
	   Supplier.companyID AS 'Company ID',        --added for sp_Report
	   Supplier.companyEmail AS 'Company Email'  -- added for sp_Report

FROM Supplier 
	INNER JOIN Food ON Supplier.companyID = Food.companyID  --joining related keys between tables
	INNER JOIN FoodAnimal ON Food.foodID = FoodAnimal.foodID 
	INNER JOIN Animal ON Animal.animalID = FoodAnimal.animalID

WHERE Food.expiryDate <= GETDATE()   
-- SELECT * FROM vw_ExpiredFoodDetails (Test View)
GO

CREATE VIEW vw_LowestFoods -- Creates a view selecting the 3 animal category records with the lowest amount of pets.
AS
SELECT TOP 3 Animal.animalCategory AS 'Category Name', SUM(Pet.numberOfPets) AS 'Total Animals'
FROM Animal
	INNER JOIN Pet ON Animal.animalID = Pet.animalID 

GROUP BY Animal.animalCategory 

ORDER BY SUM(Pet.numberOfPets) ASC 
--SELECT * FROM vw_LowestFoods (Test View)
GO