/* 
FileName: Creation_Database_Tables.sql
Programmer: Stefan Reesberg
Description: This file will create a databse and the requested tables with the necessary contraints.
*/
Use Master
GO

--Creation of database
CREATE DATABASE TygervalleyPetShelter
ON Primary
	(NAME = 'TygervalleyPetShelter',
	 FILENAME = 'c:\sql2019y\DM Project\TygervalleyPetShelter_data.mdf',
	 SIZE = 5MB,
	 FILEGROWTH = 10%)

LOG ON
	(NAME = 'TygervalleyPetShelter_Log',
	 FILENAME = 'c:\sql2019y\DM Project\TygervalleyPetShelter_Log.ldf',
	 SIZE = 5MB,
	 FILEGROWTH = 10%)
GO

--Creation of tables
USE TygervalleyPetShelter
GO

CREATE TABLE Supplier(
	companyID INT IDENTITY NOT NULL, --setting an auto-incrementing ID for the manufacturer
	companyName VARCHAR(30) NOT NULL,
	contactNum VARCHAR(15) NOT NULL,
	companyEmail VARCHAR(30),
	CONSTRAINT companyID_PK PRIMARY KEY(companyID)             
)
GO

PRINT 'The Supplier table has been created.'
GO
--All other IDs will not be auto-incrementing, used UNIQUE to ensure that there are no duplicates.

CREATE TABLE Food(                           
	foodID VARCHAR(4) UNIQUE NOT NULL, 
	foodType VARCHAR(30) NOT NULL,
	expiryDate DATETIME NOT NULL,
	companyID INT NOT NULL,
	PRIMARY KEY(foodID),
	CONSTRAINT CompanyID_FK FOREIGN KEY (companyID) REFERENCES Supplier(companyID),
	CONSTRAINT CheckExpiryDate CHECK (expiryDate >= GETDATE()-120),  --Check to see if the food has expired (4 month grace period to allow sample insertion for views and procedures)
	CONSTRAINT FoodType_UNIQUE UNIQUE (foodType)  --Unique constraint to ensure the Food Type is unique
)
GO

PRINT 'The Food table has been created.'
GO

CREATE TABLE Animal(
	animalID VARCHAR(4) UNIQUE NOT NULL,
	animalCategory VARCHAR(30) NOT NULL,
	CONSTRAINT AnimalID_PK PRIMARY KEY (animalID),
	CONSTRAINT AnimalCategory_UNIQUE UNIQUE (animalCategory) --Check to see if the animal category is unique
)
GO

PRINT 'The Animal table has been created.'
GO

CREATE TABLE Pet(
	petID VARCHAR(4) UNIQUE  NOT NULL,
	petType VARCHAR(30) NOT NULL,
	numberOfPets INT NOT NULL,
	animalID VARCHAR(4) NOT NULL,                      
	PRIMARY KEY (petID),
	CONSTRAINT AnimalID_FK FOREIGN KEY (animalID) REFERENCES Animal(animalID),
	CONSTRAINT PetType_UNIQUE UNIQUE (petType), --Check to see if the pet type is unique
	CONSTRAINT Check_NumberOfPets CHECK (numberOfPets > 0) --Check if the number of pets is higher than 0.

)
GO

PRINT 'The Pet table has been created.'
GO

CREATE TABLE FoodAnimal(
	foodID VARCHAR(4) NOT NULL,
	animalID VARCHAR(4) NOT NULL,
	amountOfFood INT NOT NULL,    
	--Creating a composite primary key for an intersection table
	PRIMARY KEY (foodID, animalID),                                      
	CONSTRAINT FoodID_FK FOREIGN KEY(foodID) REFERENCES Food(foodID),
	CONSTRAINT AnimalID_FK1 FOREIGN KEY(animalID) REFERENCES Animal (animalID),
	CONSTRAINT CheckAmountOfFood CHECK (amountOfFood > 0) --Checks if the amount of food is higher than 0.
)
GO

PRINT 'The FoodAnimal table has been created.'
GO


