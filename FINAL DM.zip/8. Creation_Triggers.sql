/*
FileName: Creation_Triggers.sql
Programmer Name: Stefan Reesberg
Description: This file creates two after triggers for each table that has been created.
*/
USE TygervalleyPetShelter
GO

--This trigger displays a message after a new record is added to the Animal table
CREATE TRIGGER Animal_TriggerI 
ON Animal
AFTER INSERT
AS
	PRINT 'A new animal record has been entered.'
GO

--This trigger displays a message after a record is updated in the Animal table
CREATE TRIGGER Animal_TriggerU
ON Animal
AFTER UPDATE
AS
	PRINT 'An animal record has been updated.'
GO

--This trigger displays a message after a new record is added to the Food table
CREATE TRIGGER Food_TriggerI
ON Food
AFTER INSERT
AS
	PRINT 'A new food record has been entered.'
GO

--This trigger displays a message after a record is updated in the Food table
CREATE TRIGGER Food_TriggerU
ON Food
AFTER UPDATE
AS
	PRINT 'A food record has been updated.'
GO

--This trigger displays a message after a new record is added to the FoodAnimal table
CREATE TRIGGER FoodAnimal_TriggerI
ON FoodAnimal
AFTER INSERT
AS
	PRINT 'A new FoodAnimal record has been entered.'
GO

--This trigger displays a message after a record is updated in the FoodAnimal table
CREATE TRIGGER FoodAnimal_TriggerU
ON FoodAnimal
AFTER UPDATE
AS
	PRINT 'A FoodAnimal record has been updated.'
GO

--This trigger displays a message after a new record is added to the Pet table
CREATE TRIGGER Pet_TriggerI
ON Pet
AFTER INSERT
AS
	PRINT 'A new pet record has been entered.'
GO

--This trigger displays a message after a record is updated in the Pet table
CREATE TRIGGER Pet_TriggerU
ON Pet
AFTER UPDATE
AS
	PRINT 'A pet record has been updated.'
GO

--This trigger displays a message after a new record is added to the Supplier table
CREATE TRIGGER Supplier_TriggerI
ON Supplier
AFTER INSERT
AS
	PRINT 'A new supplier record has been entered.'
GO

--This trigger displays a message after a record is updated in the Supplier table
CREATE TRIGGER Supplier_TriggerU
ON Supplier
AFTER UPDATE
AS
	PRINT 'A supplier record has been updated.'
GO

--Testing the trigger
INSERT INTO Pet(petID,petType,numberOfPets,animalID)
VALUES('09','Rabbit',6,(SELECT animalID FROM Animal WHERE animalCategory = 'Mammal'))